
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		estilo_android_app
	 *	@date 		Wednesday 16th of November 2022 08:16:20 AM
	 *	@title 		Page 1
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package exportkit.figma;

import android.app.Activity;
import android.os.Bundle;


import android.view.View;
import android.widget.ImageView;

public class estilo_android_app_activity extends Activity {

	
	private View _bg__estilo_android_app_ek2;
	private ImageView vector_1;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.estilo_android_app);

		
		_bg__estilo_android_app_ek2 = (View) findViewById(R.id._bg__estilo_android_app_ek2);
		vector_1 = (ImageView) findViewById(R.id.vector_1);
	
		
		//custom code goes here
	
	}
}
	
	