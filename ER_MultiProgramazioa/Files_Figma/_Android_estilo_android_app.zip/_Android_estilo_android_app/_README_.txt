Export Kit - Lightning Storm CC
Android Studio Projects Update (July 25, 2019):

  1. Copy all files and folders in your "Page 1" 
     export directory (this folder).

  2. Locate your Android Studio Projects folder.  

     Default Locations
     -----------------
     WIN: %userprofile%\StudioProjects
     MAC: ~\StudioProjects

  3. Create a new Android Studio Project with the name 
     "Page 1" and ensure you are using 
     "Add no Activity" during the Activity Settings.

  4. Paste and *replace all* files and folders located in 
     your project folder { Page 1/app/src/main } with 
     the contents copied in Step 1.

  5. Done!